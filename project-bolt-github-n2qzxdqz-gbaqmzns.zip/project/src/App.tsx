import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import PainOutcome from './components/PainOutcome';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import Results from './components/Results';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-background text-text">
      <Header />
      <main>
        <Hero />
        <PainOutcome />
        <Features />
        <HowItWorks />
        <Results />
        <Pricing />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;