import React from 'react';
import { TrendingUp, Clock, Shield, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';

const Results: React.FC = () => {
  const stats = [
    {
      icon: TrendingUp,
      value: '2-10×',
      label: 'Faster gap filling',
      description: 'Hosts fill cancellation gaps 2–10× faster'
    },
    {
      icon: Clock,
      value: '<60s',
      label: 'Response time',
      description: 'Avg response times cut to <60 seconds'
    },
    {
      icon: Shield,
      value: '90%',
      label: 'Better reviews',
      description: 'Higher-quality guests lead to better reviews and improved Google ranking'
    }
  ];

  return (
    <section id="results" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-space font-bold mb-6">
            Real <span className="text-gradient">results</span> from real hosts
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            See the impact on your revenue and guest experience
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass rounded-2xl p-8 text-center card-hover"
            >
              <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-primary/20 flex items-center justify-center">
                <stat.icon size={32} className="text-primary" />
              </div>
              
              <div className="text-4xl font-space font-bold text-gradient mb-2">
                {stat.value}
              </div>
              
              <h3 className="text-lg font-semibold mb-3">{stat.label}</h3>
              <p className="text-muted text-sm">{stat.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Case Study */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="glass rounded-2xl p-8 max-w-4xl mx-auto"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
              <DollarSign size={24} className="text-success" />
            </div>
            <div>
              <h3 className="text-xl font-space font-semibold">Success Story</h3>
              <p className="text-muted">Real results from a ZeroLiftAI user</p>
            </div>
          </div>
          
          <div className="bg-background/50 rounded-xl p-6 border border-success/20">
            <p className="text-lg mb-4">
              <span className="text-success font-semibold">$462 gap rebooked in 27 minutes.</span>
            </p>
            <p className="text-muted">
              "A last-minute cancellation on Friday evening would have cost me the entire weekend. 
              ZeroLiftAI detected it immediately and had three qualified guests competing for the dates. 
              Booked within the hour at full price."
            </p>
            <div className="mt-4 text-sm text-muted/70">
              — Sarah M., Superhost with 12 properties
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Results;