import React from 'react';
import { Play } from 'lucide-react';
import { motion } from 'framer-motion';

const Hero: React.FC = () => {
  return (
    <section className="h-screen flex items-center justify-center bg-background relative overflow-hidden">
      {/* Subtle Background Elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-10 w-[500px] h-[500px] bg-secondary/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10 text-center">
        {/* Massive Two-Line Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="font-space font-black leading-[0.85] tracking-tight mb-8"
          style={{ fontSize: 'clamp(3rem, 12vw, 10rem)' }}
        >
          <div 
            className="block mb-4"
            style={{
              background: 'linear-gradient(135deg, #00E0FF 0%, #0099CC 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              filter: 'drop-shadow(0 0 30px rgba(0, 224, 255, 0.5))'
            }}
          >
            ZERO CANCELLATION
          </div>
          <div 
            className="block"
            style={{
              background: 'linear-gradient(135deg, #7C5CFF 0%, #FF6B9D 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              filter: 'drop-shadow(0 0 30px rgba(124, 92, 255, 0.5))'
            }}
          >
            REVENUE LOSS
          </div>
        </motion.h1>
        
        {/* Large Centered Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-4xl md:text-5xl lg:text-6xl font-space font-bold text-center mb-8 text-white"
          style={{
            textShadow: '0 0 40px rgba(0, 224, 255, 0.6), 0 0 80px rgba(124, 92, 255, 0.3)',
            filter: 'drop-shadow(0 0 20px rgba(255, 255, 255, 0.3))'
          }}
        >
          AI that stops lost bookings before they happen.
        </motion.p>
        
        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-xl md:text-2xl text-muted max-w-2xl mx-auto font-medium"
        >
          AI automations that instantly rebook gaps and protect your income.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex flex-col sm:flex-row gap-6 justify-center mt-12"
        >
          <button className="btn-primary text-xl px-12 py-6 shadow-2xl shadow-primary/30">
            🚀 Get Demo + Pricing
          </button>
          <button className="btn-secondary text-xl px-12 py-6 flex items-center justify-center gap-3 group">
            <Play size={24} className="group-hover:scale-110 transition-transform" />
            Watch $462 Recovery
          </button>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.3 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-bounce"></div>
        </div>
      </motion.div>
    </section>
  );
};

export default Hero;