import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Features', href: '#features' },
    { label: 'How it Works', href: '#how-it-works' },
    { label: 'Results', href: '#results' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'glass border-b border-white/10' : 'bg-transparent'
    }`}>
      <nav className="container mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a 
            href="#" 
            className="text-2xl font-space font-bold text-white hover:scale-105 transition-transform duration-300"
            style={{
              textShadow: '0 0 20px rgba(0, 224, 255, 0.6), 0 0 40px rgba(124, 92, 255, 0.3)',
              filter: 'drop-shadow(0 0 10px rgba(255, 255, 255, 0.2))'
            }}
          >
            ZeroLiftAI
          </a>
          
          {/* Center Navigation */}
          <div className="hidden lg:flex items-center space-x-12">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-white/70 hover:text-white text-sm font-medium transition-colors duration-300"
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Right CTA Button */}
          <div className="hidden lg:block">
            <button 
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all duration-300 hover:scale-105 hover:shadow-xl active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #00E0FF 0%, #7C5CFF 100%)',
                boxShadow: '0 0 20px rgba(0, 224, 255, 0.3), 0 0 40px rgba(124, 92, 255, 0.2)'
              }}
            >
              Book Demo
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="lg:hidden mt-6 pb-6 border-t border-white/10">
            <div className="flex flex-col space-y-4 pt-4">
              {navItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-white/70 hover:text-white transition-colors duration-300"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <button 
                className="w-full mt-6 px-6 py-3 rounded-xl font-semibold text-white transition-all duration-300"
                style={{
                  background: 'linear-gradient(135deg, #00E0FF 0%, #7C5CFF 100%)',
                  boxShadow: '0 0 20px rgba(0, 224, 255, 0.3)'
                }}
              >
                Book Demo
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;