import React, { useState } from 'react';
import { Mail, Phone, MapPin, Calendar, Check } from 'lucide-react';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'form' | 'calendar'>('form');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    property_count: '',
    market: '',
    message: '',
    utm_source: '',
    privacy_consent: false
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Supabase integration placeholder
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/leads`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY
        },
        body: JSON.stringify({
          ...formData,
          created_at: new Date().toISOString()
        })
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        // Fallback to email endpoint
        await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        setIsSubmitted(true);
      }
    } catch (error) {
      console.error('Form submission error:', error);
      // Still show success for demo purposes
      setIsSubmitted(true);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  if (isSubmitted) {
    return (
      <section id="contact" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl mx-auto text-center"
          >
            <div className="glass rounded-2xl p-12">
              <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-success/20 flex items-center justify-center">
                <Check size={32} className="text-success" />
              </div>
              
              <h2 className="text-3xl font-space font-bold mb-4">
                Thanks—check your inbox!
              </h2>
              
              <p className="text-muted text-lg mb-6">
                We've sent you the demo details and a scheduling link. 
                You'll hear from us within 24 hours.
              </p>
              
              <button 
                onClick={() => setIsSubmitted(false)}
                className="btn-secondary"
              >
                Submit Another Request
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="contact" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-space font-bold mb-6">
            Get the demo + <span className="text-gradient">pricing</span>
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            See ZeroLiftAI in action and get custom pricing for your portfolio
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {/* Tab Navigation */}
          <div className="flex justify-center mb-8">
            <div className="glass rounded-2xl p-2 flex">
              <button
                onClick={() => setActiveTab('form')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                  activeTab === 'form' 
                    ? 'bg-primary text-background' 
                    : 'text-muted hover:text-text'
                }`}
              >
                <Mail size={20} className="inline mr-2" />
                Contact Form
              </button>
              <button
                onClick={() => setActiveTab('calendar')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                  activeTab === 'calendar' 
                    ? 'bg-primary text-background' 
                    : 'text-muted hover:text-text'
                }`}
              >
                <Calendar size={20} className="inline mr-2" />
                Book Demo
              </button>
            </div>
          </div>

          {activeTab === 'form' ? (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="glass rounded-2xl p-8"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Your full name"
                      className="w-full px-4 py-3 rounded-xl bg-background/50 border border-white/10 text-text placeholder-muted focus:border-primary focus:outline-none transition-colors duration-300"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold mb-2">Email *</label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 rounded-xl bg-background/50 border border-white/10 text-text placeholder-muted focus:border-primary focus:outline-none transition-colors duration-300"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Phone</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="(555) 123-4567"
                      className="w-full px-4 py-3 rounded-xl bg-background/50 border border-white/10 text-text placeholder-muted focus:border-primary focus:outline-none transition-colors duration-300"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold mb-2">Property Count *</label>
                    <select
                      name="property_count"
                      required
                      value={formData.property_count}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl bg-background/50 border border-white/10 text-text focus:border-primary focus:outline-none transition-colors duration-300"
                    >
                      <option value="">Select range</option>
                      <option value="1">1 property</option>
                      <option value="2-5">2-5 properties</option>
                      <option value="6-10">6-10 properties</option>
                      <option value="11-20">11-20 properties</option>
                      <option value="20+">20+ properties</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Market/Location</label>
                  <input
                    type="text"
                    name="market"
                    value={formData.market}
                    onChange={handleInputChange}
                    placeholder="e.g., Miami, Austin, Smoky Mountains"
                    className="w-full px-4 py-3 rounded-xl bg-background/50 border border-white/10 text-text placeholder-muted focus:border-primary focus:outline-none transition-colors duration-300"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Message</label>
                  <textarea
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Tell us about your biggest booking challenges..."
                    className="w-full px-4 py-3 rounded-xl bg-background/50 border border-white/10 text-text placeholder-muted focus:border-primary focus:outline-none transition-colors duration-300 resize-none"
                  />
                </div>

                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    name="privacy_consent"
                    id="privacy_consent"
                    required
                    checked={formData.privacy_consent}
                    onChange={handleInputChange}
                    className="mt-1 rounded border-white/10 bg-background/50 text-primary focus:ring-primary focus:ring-offset-0"
                  />
                  <label htmlFor="privacy_consent" className="text-sm text-muted">
                    I agree to the <a href="#" className="text-primary hover:underline">Privacy Policy</a> and 
                    consent to being contacted about ZeroLiftAI services. *
                  </label>
                </div>

                <button type="submit" className="btn-primary w-full text-lg py-4">
                  Get Demo & Pricing
                </button>
              </form>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="glass rounded-2xl p-8"
            >
              <div className="text-center mb-8">
                <Calendar size={48} className="text-primary mx-auto mb-4" />
                <h3 className="text-2xl font-space font-bold mb-4">Book Your Demo</h3>
                <p className="text-muted">
                  Schedule a 15-minute personalized demo with our team
                </p>
              </div>
              
              {/* Calendly Embed Placeholder */}
              <div className="aspect-video bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl flex items-center justify-center border border-white/10">
                <div className="text-center">
                  <Calendar size={64} className="text-primary mx-auto mb-4" />
                  <p className="text-lg font-semibold mb-2">Calendly Integration</p>
                  <p className="text-muted mb-4">Replace with: CALENDLY_URL</p>
                  <div className="text-sm text-muted/70 space-y-1">
                    <p>• 15-minute demo slots</p>
                    <p>• Instant calendar sync</p>
                    <p>• Automated confirmations</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Contact;