import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: 'Which platforms does ZeroLiftAI support?',
      answer: 'We integrate with Airbnb, VRBO, Booking.com, and most major vacation rental platforms. We also work with property management systems like Hostfully, Guesty, and OwnerRez.'
    },
    {
      question: 'How long does setup take?',
      answer: 'Most hosts are up and running within 15 minutes. Our team handles the technical integration while you simply connect your accounts through our secure OAuth process.'
    },
    {
      question: 'Is my data secure?',
      answer: 'Absolutely. We use bank-level encryption, are SOC 2 compliant, and never store sensitive guest payment information. Your data is protected with the same security standards used by major financial institutions.'
    },
    {
      question: 'What happens if I get a cancellation?',
      answer: 'Within minutes of detecting a cancellation, ZeroLiftAI identifies qualified leads from your inquiry history and sends personalized first-to-claim offers. The system handles everything automatically while keeping you informed.'
    },
    {
      question: 'Do you support SMS and email outreach?',
      answer: 'Yes, we support both SMS and email channels. The system intelligently chooses the best communication method based on guest preferences and response history to maximize booking conversion.'
    },
    {
      question: 'What are the contract terms?',
      answer: 'We offer flexible month-to-month plans with no long-term commitments. You can upgrade, downgrade, or cancel anytime. Most hosts see ROI within the first month.'
    },
    {
      question: 'How does guest scoring work?',
      answer: 'Our AI analyzes public review data across platforms to identify patterns in guest behavior (cleanliness, communication, house rules compliance). You get clear Good/Neutral/Caution ratings with specific insights. Better guest selection leads to better reviews, which improves your Google ranking and visibility.'
    },
    {
      question: 'How does this help my Google ranking?',
      answer: 'By helping you select better guests and respond faster to inquiries, you\'ll get more positive reviews and maintain higher response rates. Google factors review quality, quantity, and response times into local search rankings for vacation rentals.'
    },
    {
      question: 'Can I customize the AI responses?',
      answer: 'Yes, you can customize response templates, set your preferred tone, and add property-specific information. The AI learns your style and maintains consistency across all guest interactions.'
    }
  ];

  return (
    <section id="faq" className="py-20 gradient-bg">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-space font-bold mb-6">
            Frequently asked <span className="text-gradient">questions</span>
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            Everything you need to know about ZeroLiftAI
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="glass rounded-2xl mb-4 overflow-hidden"
            >
              <button
                className="w-full p-6 text-left flex items-center justify-between hover:bg-white/5 transition-colors duration-300"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <h3 className="text-lg font-semibold pr-4">{faq.question}</h3>
                {openIndex === index ? (
                  <ChevronUp size={20} className="text-primary flex-shrink-0" />
                ) : (
                  <ChevronDown size={20} className="text-muted flex-shrink-0" />
                )}
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6">
                      <p className="text-muted leading-relaxed">{faq.answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;