import React from 'react';
import { Search, Send, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: Search,
      title: 'Detect',
      description: 'We watch your booking calendar for openings/cancellations.',
      color: 'text-primary'
    },
    {
      icon: Send,
      title: 'Outreach',
      description: 'The assistant messages qualified leads with time-boxed claim links.',
      color: 'text-secondary'
    },
    {
      icon: CheckCircle,
      title: 'Rebook',
      description: 'First to claim locks dates; everyone else gets alternates or waitlist.',
      color: 'text-success'
    }
  ];

  return (
    <section id="how-it-works" className="py-20 gradient-bg">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-space font-bold mb-6">
            How it <span className="text-gradient">works</span>
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            Three simple steps to never lose revenue to cancellations again
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connection Lines */}
          <div className="hidden md:block absolute top-1/2 left-1/3 right-1/3 h-0.5 bg-gradient-to-r from-primary via-secondary to-success opacity-30 -translate-y-1/2"></div>
          
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="text-center relative z-10"
            >
              <div className="glass rounded-2xl p-8 card-hover">
                <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-${step.color.split('-')[1]}/20 to-${step.color.split('-')[1]}/5 flex items-center justify-center`}>
                  <step.icon size={32} className={step.color} />
                </div>
                
                <h3 className="text-xl font-space font-semibold mb-4">{step.title}</h3>
                <p className="text-muted leading-relaxed">{step.description}</p>
                
                <div className="mt-6 text-sm text-muted/70">
                  Step {index + 1}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;