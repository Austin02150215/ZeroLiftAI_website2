import React from 'react';
import { Zap, MessageCircle, Star } from 'lucide-react';
import { motion } from 'framer-motion';

const Features: React.FC = () => {
  const features = [
    {
      icon: Zap,
      title: 'Gap Filler',
      description: 'When a booking falls through, ZeroLiftAI identifies the open dates and instantly contacts qualified leads with a first-to-claim link. The first guest to confirm locks the stay; everyone else receives a polite update and alternative dates.',
      visual: (
        <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl flex items-center justify-center">
          <div className="text-center">
            <Zap size={48} className="text-primary mx-auto mb-2" />
            <p className="text-sm text-muted">Gap Detection Animation</p>
          </div>
        </div>
      )
    },
    {
      icon: MessageCircle,
      title: 'Instant Replies',
      description: 'Answer guest questions in seconds—day or night. Protect your response metrics and never lose a booking to a faster host.',
      visual: (
        <div className="aspect-video bg-gradient-to-br from-secondary/20 to-secondary/5 rounded-xl flex items-center justify-center">
          <div className="text-center">
            <MessageCircle size={48} className="text-secondary mx-auto mb-2" />
            <p className="text-sm text-muted">Response Time Visualization</p>
          </div>
        </div>
      )
    },
    {
      icon: Star,
      title: 'Guest Scoring',
      description: 'We summarize past host reviews and flag patterns (cleanliness, late checkout, damage) so you decide with confidence. Better guests = better reviews = higher Google ranking.',
      visual: (
        <div className="aspect-video bg-gradient-to-br from-success/20 to-success/5 rounded-xl flex items-center justify-center">
          <div className="text-center">
            <Star size={48} className="text-success mx-auto mb-2" />
            <p className="text-sm text-muted">Guest Scoring + Review Impact</p>
          </div>
        </div>
      )
    }
  ];

  return (
    <section id="features" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-space font-bold mb-6">
            AI that works while you <span className="text-gradient">sleep</span>
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            Three powerful automations that protect your revenue and guest experience
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass rounded-2xl p-8 card-hover"
            >
              <div className="mb-6">
                {feature.visual}
              </div>
              
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-xl bg-primary/20">
                  <feature.icon size={24} className="text-primary" />
                </div>
                <h3 className="text-xl font-space font-semibold">{feature.title}</h3>
              </div>
              
              <p className="text-muted leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;