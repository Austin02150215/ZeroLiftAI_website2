import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center space-x-3">
      <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
        <span className="text-background font-bold text-xl font-space">Z</span>
      </div>
      <span className="text-xl font-space font-semibold text-text">ZeroLiftAI</span>
    </div>
  );
};

export default Logo;