import React from 'react';
import { Calendar, MessageSquare, UserCheck, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const PainOutcome: React.FC = () => {
  const items = [
    {
      icon: Calendar,
      pain: 'Empty nights = lost revenue',
      outcome: 'Auto-rebook gaps',
      color: 'text-primary'
    },
    {
      icon: MessageSquare,
      pain: 'Slow replies hurt ranking',
      outcome: 'Instant inquiry replies',
      color: 'text-secondary'
    },
    {
      icon: UserCheck,
      pain: 'Bad reviews hurt ranking',
      outcome: 'Better guests = better reviews',
      color: 'text-success'
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {items.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="flex items-center justify-center mb-6">
                <div className={`p-4 rounded-2xl glass ${item.color}`}>
                  <item.icon size={32} />
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-4 mb-4">
                <span className="text-muted text-sm">{item.pain}</span>
                <ArrowRight size={16} className="text-primary" />
                <span className="text-text font-semibold text-sm">{item.outcome}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PainOutcome;