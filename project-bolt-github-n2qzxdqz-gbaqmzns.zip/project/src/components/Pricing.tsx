import React from 'react';
import { Check, Zap, MessageCircle, Star, Building } from 'lucide-react';
import { motion } from 'framer-motion';

const Pricing: React.FC = () => {
  const plans = [
    {
      name: 'Starter',
      icon: Zap,
      description: 'Core Gap Filler',
      price: 'Custom',
      features: [
        'Automatic gap detection',
        'Qualified lead outreach',
        'First-to-claim booking',
        'Guest scoring for better reviews',
        'Basic analytics',
        'Email support'
      ],
      cta: 'Book Demo',
      popular: false
    },
    {
      name: 'Pro',
      icon: MessageCircle,
      description: '+ Instant Replies',
      price: 'Custom',
      features: [
        'Everything in Starter',
        '24/7 AI guest responses',
        'Response time protection',
        'Review optimization insights',
        'Advanced analytics',
        'Priority support'
      ],
      cta: 'Book Demo',
      popular: true
    },
    {
      name: 'Plus',
      icon: Star,
      description: '+ Guest Scoring & Multi-property',
      price: 'Custom',
      features: [
        'Everything in Pro',
        'Guest scoring & summaries',
        'Google ranking optimization',
        'Multi-property management',
        'Custom integrations',
        'Dedicated success manager'
      ],
      cta: 'Book Demo',
      popular: false
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-space font-bold mb-6">
            Simple <span className="text-gradient">pricing</span>
          </h2>
          <p className="text-xl text-muted max-w-3xl mx-auto">
            Choose the plan that fits your portfolio size and needs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`glass rounded-2xl p-8 card-hover relative ${
                plan.popular ? 'ring-2 ring-primary' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-primary text-background px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </div>
                </div>
              )}
              
              <div className="text-center mb-8">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-primary/20 flex items-center justify-center">
                  <plan.icon size={32} className="text-primary" />
                </div>
                
                <h3 className="text-2xl font-space font-bold mb-2">{plan.name}</h3>
                <p className="text-muted mb-4">{plan.description}</p>
                
                <div className="text-3xl font-space font-bold text-gradient mb-2">
                  {plan.price}
                </div>
                <p className="text-sm text-muted">Pricing based on portfolio size</p>
              </div>
              
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <Check size={16} className="text-success flex-shrink-0" />
                    <span className="text-muted">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`w-full py-3 rounded-2xl font-semibold transition-all duration-300 ${
                plan.popular 
                  ? 'btn-primary' 
                  : 'btn-secondary'
              }`}>
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>

        {/* Enterprise */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="glass rounded-2xl p-8 max-w-4xl mx-auto text-center"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Building size={32} className="text-secondary" />
            <h3 className="text-2xl font-space font-bold">Enterprise</h3>
          </div>
          
          <p className="text-muted mb-6">
            Custom solutions for 20+ properties with dedicated support and advanced features
          </p>
          
          <button className="btn-secondary">
            Contact Sales
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;